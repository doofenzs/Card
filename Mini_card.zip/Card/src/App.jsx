import Card from "./Card.jsx";
import "./index.css";


function App() {
  const handleContact = () => {
    console.log('contact button clicked');
  };

    return(
      <div className="app">
        <Card 
          name="Ashutosh Salunke"
          jobTittle="Web-Dev"
          bio="Love to do coding"
          contact={handleContact}
        
        />
      </div>
    );
}

export default App  